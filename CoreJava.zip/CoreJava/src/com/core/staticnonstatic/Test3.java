package com.core.staticnonstatic;

public class Test3 {

	
}
