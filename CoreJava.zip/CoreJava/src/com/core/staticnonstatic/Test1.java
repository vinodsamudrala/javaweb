package com.core.staticnonstatic;

public class Test1 {
	
	static int count = 0;
	
	int data = 0;
	
	String name = "";
	
}

