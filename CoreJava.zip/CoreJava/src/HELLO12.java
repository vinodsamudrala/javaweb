public class HELLO12 {

	int x=100;
	static int y = 200;
	
	public static void main(String args[]) {
		
		HELLO12 h1= new HELLO12();
		
		System.out.println("y:"+ y);
		System.out.println("x:"+ h1.x);
		
	}
}
